#include <iostream>
#include <vector>
#include <string>

class Room {
public:
    int roomNumber;
    bool isOccupied;
    Room(int number) : roomNumber(number), isOccupied(false) {}
};

class Hotel {
private:
    std::vector<Room> rooms;

public:
    Hotel(int numRooms) {
        for (int i = 1; i <= numRooms; ++i) {
            rooms.push_back(Room(i));
        }
    }

    void displayAvailableRooms() {
        std::cout << "Available Rooms: ";
        for (const Room& room:rooms) {
            if (!room.isOccupied) {
                std::cout << room.roomNumber << " ";
            }
        }
        std::cout << std::endl;
    }

    void bookRoom(int roomNumber) {
        if (roomNumber >= 1 && roomNumber <= rooms.size()) {
            Room& room = rooms[roomNumber - 1];
            if (!room.isOccupied) {
                room.isOccupied = true;
                std::cout << "Room " << roomNumber << " booked successfully." << std::endl;
            } else {
                std::cout << "Room " << roomNumber << " is already occupied." << std::endl;
            }
        } else {
            std::cout << "Invalid room number." << std::endl;
        }
    }

    void checkoutRoom(int roomNumber) {
        if (roomNumber >= 1 && roomNumber <= rooms.size()) {
            Room& room = rooms[roomNumber - 1];
            if (room.isOccupied) {
                room.isOccupied = false;
                std::cout << "Room " << roomNumber << " has been checked out." << std::endl;
            } else {
                std::cout << "Room " << roomNumber << " is not occupied." << std::endl;
            }
        } else {
            std::cout << "Invalid room number." << std::endl;
        }
    }
};

int main() {
    Hotel hotel(10); // Create a hotel with 10 rooms
    int choice, roomNumber;

    do {
        std::cout << "1. Display available rooms" << std::endl;
        std::cout << "2. Book a room" << std::endl;
        std::cout << "3. Checkout from a room" << std::endl;
        std::cout << "4. Exit" << std::endl;
        std::cout << "Enter your choice: ";
        std::cin >> choice;

        switch (choice) {
            case 1:
                hotel.displayAvailableRooms();
                break;
            case 2:
                std::cout << "Enter room number to book: ";
                std::cin >> roomNumber;
                hotel.bookRoom(roomNumber);
                break;
            case 3:
                std::cout << "Enter room number to checkout: ";
                std::cin >> roomNumber;
                hotel.checkoutRoom(roomNumber);
                break;
            case 4:
                std::cout << "Exiting program." << std::endl;
                break;
            default:
                std::cout << "Invalid choice." << std::endl;
        }

    } while (choice != 4);

    return 0;
}
